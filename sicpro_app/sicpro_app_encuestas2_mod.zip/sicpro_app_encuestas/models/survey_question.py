# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import json
from collections import Counter

class SurveyQuestion(models.Model):
    """ Encuesta.pregunta heredada para agregar un tipo de pregunta personalizada"""
    _inherit = 'survey.question'

    selection_ids = fields.One2many('question.selection', 'question_id', string='Selección',
                                    help="Campo utilizado para crear preguntas de tipo selección.")
    question_type = fields.Selection(
        selection_add=[('time', 'Tiempo'), ('month', 'Mes'), ('name', 'Nombre'), ('address', 'Dirección'),
                       ('email', 'Correo Electrónico'), ('password', 'Contraseña'), ('qr', 'Código QR'), ('url', 'URL'),
                       ('week', 'Semana'), ('color', 'Color'), ('range', 'Rango'), ('many2one', 'Many2one'),
                       ('file', 'Subir archivo'), ('date', 'Fecha'), ('many2many', 'Many2many'),
                       ('selection', 'selección'), ('barcode', 'código de barras')],
        help="Tipos de preguntas admitidas por encuestas")
    matrix_subtype = fields.Selection(selection_add=[('custom', 'Matriz personalizada')],
                                      help="Pregunta de tipo de selección de matriz")
    model_id = fields.Many2one('ir.model', string='Modelo', domain=[('transient', '=', False)],
                               help="pregunta tipo many2one")
    range_min = fields.Integer(string='Min', help='Rango mínimo, pregunta de tipo de rango')
    range_max = fields.Integer(string='Max', help='Rango máximo, pregunta de tipo de rango')
    qrcode = fields.Text(string='Qrcode', help='Mostrar código qr en la encuesta')
    qrcode_png = fields.Binary(string='Qrcode PNG', help="Código QR PNG")
    barcode = fields.Char(string='Barcode', help="Número de código de barras")
    barcode_png = fields.Binary(string='Barcode PNG', help="Guarda el archivo png de código de barras")

    @api.constrains('barcode')
    def _check_barcode(self):
        """Restricción para garantizar que el código de barras tenga exactamente 12 dígitos."""
        for record in self:
            if record.barcode:
                if len(record.barcode) != 12:
                    raise ValidationError(_("El código de barras debe tener exactamente 12 caracteres."))
                if not record.barcode.isdigit():
                    raise ValidationError(_("El código de barras debe contener solo dígitos."))

    def get_selection_values(self):
        """Opciones de devolución de funciones para preguntas de tipo de selección"""
        return self.selection_ids

    def prepare_model_id(self, model):
        """Función para devolver opciones para muchas preguntas"""
        if model:
            model_data = self.env[model.model].sudo().search([])
            return [rec.read([model_data._rec_name])[0] for rec in model_data]
        model_data = self.env[self.model_id.model].sudo().search([])
        return [rec.read([model_data._rec_name])[0] for rec in model_data]

    @api.model
    def _prepare_statistics(self, user_input_lines=None):
        results = []
        for question in self:
            if user_input_lines:
                q_lines = user_input_lines.filtered(lambda l: l.question_id.id == question.id)
            else:
                q_lines = self.env['survey.user_input.line'].sudo().search([('question_id','=',question.id),('skipped','=',False)])

            done = q_lines.filtered(lambda l: not l.skipped)
            skipped = q_lines.filtered(lambda l: l.skipped)
            comment_lines = q_lines.filtered(lambda l: l.answer_type in ['char_box','text_box'] and l.value_text_box)

            data = {'question': question,
                    'answer_input_done_ids': done,
                    'answer_input_skipped_ids': skipped,
                    'comment_line_ids': comment_lines,
                    'graph_data': None,
                    'table_data': [],
                    'right_answers': [],
                    'right_inputs_count': 0,
                    'partial_inputs_count': 0}

            qtype = question.question_type

            if qtype in ['text_box','char_box','datetime','time','date','month','url','email','password']:
                data['table_data'] = list(done)

            elif qtype == 'selection':
                vals = [ (l.value_selection or '') for l in done ]
                counts = Counter(vals)
                data['table_data'] = [{'value':v,'count':c,'suggested_answer':False} for v,c in counts.items()]
                data['graph_data'] = [{'text':v,'count':c} for v,c in counts.items()]

            elif qtype == 'many2one':
                vals = [ (l.value_many2one_option or '') for l in done ]
                counts = Counter(vals)
                data['table_data'] = [{'value':v,'count':c,'suggested_answer':False} for v,c in counts.items()]
                data['graph_data'] = [{'text':v,'count':c} for v,c in counts.items()]

            elif qtype == 'many2many':
                all_items = []
                for l in done:
                    try:
                        items = json.loads(l.value_many2many) if l.value_many2many else []
                    except Exception:
                        items = []
                    if isinstance(items, (list,tuple)):
                        all_items += items
                counts = Counter(all_items)
                data['table_data'] = [{'value':v,'count':c,'suggested_answer':False} for v,c in counts.items()]
                data['graph_data'] = [{'text':v,'count':c} for v,c in counts.items()]

            elif qtype == 'range':
                nums = []
                for l in done:
                    try:
                        nums.append(float(l.value_range))
                    except Exception:
                        pass
                if nums:
                    data['numerical_min'] = min(nums)
                    data['numerical_max'] = max(nums)
                    data['numerical_average'] = sum(nums)/len(nums)
                data['table_data'] = [{'value':v,'count':1} for v in nums]

            elif qtype in ['barcode','qr','name','address','color','week']:
                data['table_data'] = list(done)

            elif qtype == 'matrix' and question.matrix_subtype == 'custom':
                data['table_data'] = list(done)

            if qtype == 'time':
                buckets = Counter()
                for l in done:
                    val = l.value_time or ''
                    if val:
                        try:
                            hour = int(str(val).split(':')[0])
                        except Exception:
                            hour = None
                        if hour is not None:
                            buckets[f"{hour}:00"] += 1
                data['graph_data'] = [{'text':k,'count':v} for k,v in buckets.items()] if buckets else data['graph_data']

            if qtype == 'month':
                buckets = Counter()
                for l in done:
                    val = l.value_month or ''
                    if val:
                        buckets[val] += 1
                data['graph_data'] = [{'text':k,'count':v} for k,v in buckets.items()] if buckets else data['graph_data']

            if qtype == 'week':
                buckets = Counter()
                for l in done:
                    val = l.value_week or ''
                    if val:
                        buckets[val] += 1
                data['graph_data'] = [{'text':k,'count':v} for k,v in buckets.items()] if buckets else data['graph_data']

            results.append(data)
        return results