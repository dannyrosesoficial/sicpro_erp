# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SurveyQuestion(models.Model):
    """ Encuesta.pregunta heredada para agregar un tipo de pregunta personalizada"""
    _inherit = 'survey.question'

    selection_ids = fields.One2many('question.selection', 'question_id', string='Selección',
                                    help="Campo utilizado para crear preguntas de tipo selección.")
    question_type = fields.Selection(
        selection_add=[('time', 'Tiempo'), ('month', 'Mes'), ('name', 'Nombre'), ('address', 'Dirección'),
                       ('email', 'Correo Electrónico'), ('password', 'Contraseña'), ('qr', 'Código QR'), ('url', 'URL'),
                       ('week', 'Semana'), ('color', 'Color'), ('range', 'Rango'), ('many2one', 'Many2one'),
                       ('file', 'Subir archivo'), ('date', 'Fecha'), ('many2many', 'Many2many'),
                       ('selection', 'selección'), ('barcode', 'código de barras')],
        help="Tipos de preguntas admitidas por encuestas")
    matrix_subtype = fields.Selection(selection_add=[('custom', 'Matriz personalizada')],
                                      help="Pregunta de tipo de selección de matriz")
    model_id = fields.Many2one('ir.model', string='Modelo', domain=[('transient', '=', False)],
                               help="pregunta tipo many2one")
    range_min = fields.Integer(string='Min', help='Rango mínimo, pregunta de tipo de rango')
    range_max = fields.Integer(string='Max', help='Rango máximo, pregunta de tipo de rango')
    qrcode = fields.Text(string='Qrcode', help='Mostrar código qr en la encuesta')
    qrcode_png = fields.Binary(string='Qrcode PNG', help="Código QR PNG")
    barcode = fields.Char(string='Barcode', help="Número de código de barras")
    barcode_png = fields.Binary(string='Barcode PNG', help="Guarda el archivo png de código de barras")

    @api.constrains('barcode')
    def _check_barcode(self):
        """Restricción para garantizar que el código de barras tenga exactamente 12 dígitos."""
        for record in self:
            if record.barcode:
                if len(record.barcode) != 12:
                    raise ValidationError(_("El código de barras debe tener exactamente 12 caracteres."))
                if not record.barcode.isdigit():
                    raise ValidationError(_("El código de barras debe contener solo dígitos."))

    def get_selection_values(self):
        """Opciones de devolución de funciones para preguntas de tipo de selección"""
        return self.selection_ids

    def prepare_model_id(self, model):
        """Función para devolver opciones para muchas preguntas"""
        if model:
            model_data = self.env[model.model].sudo().search([])
            return [rec.read([model_data._rec_name])[0] for rec in model_data]
        model_data = self.env[self.model_id.model].sudo().search([])
        return [rec.read([model_data._rec_name])[0] for rec in model_data]
